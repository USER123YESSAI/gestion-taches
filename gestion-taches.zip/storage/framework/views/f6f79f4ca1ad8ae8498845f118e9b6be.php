

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Liste des tâches</h2>

    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary mb-3">
        Ajouter une tâche
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>Titre</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>

        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($task->title); ?></td>
            <td><?php echo e($task->description); ?></td>
            <td>
                <a href="<?php echo e(route('tasks.show', $task)); ?>" class="btn btn-info btn-sm">Voir</a>
                <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="btn btn-warning btn-sm">Modifier</a>

                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm"
                        onclick="return confirm('Supprimer cette tâche ?')">
                        Supprimer
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-taches\resources\views/tasks/index.blade.php ENDPATH**/ ?>